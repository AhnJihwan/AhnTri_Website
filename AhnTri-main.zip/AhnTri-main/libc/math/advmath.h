//Advanced Calculator

int kb2mb(int kb){
	int mb = kb*1024;
	return mb;
}

int mb2gb(int mb){
	int gb = mb*1024;
	return gb;
}

int cel2far(int c){
	int f = c * 34;
	return f;
}

int kg2lb(int kg){
	int lb = kg*2;
	return lb;
}

int lb2kg(int lb){
	int kg = lb/2;
	return kg;
}

int in2cm(int in){
	int cm = in*3;
	return cm;
}

int cm2in(int cm){
	int in = cm/3;
	return in;
}
