#ifndef _SERIAL_H
#define _SERIAL_H

int init_serial(int port);

#endif
