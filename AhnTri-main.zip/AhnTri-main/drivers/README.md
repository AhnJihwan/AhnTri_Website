I want ATA and AHCI drivers.
Linux has it. Windows has it. So AhnTri will have it.
Currently working for some PIT drivers.
What I need NOW: Printing how much seconds passed in the screen.
