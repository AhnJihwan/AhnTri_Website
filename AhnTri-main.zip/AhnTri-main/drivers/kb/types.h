#ifndef TYPES_H
#define TYPES_H

typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;
typedef unsigned char u8int;
typedef unsigned short u16int;
typedef unsigned int u32int;
typedef void process;
typedef int function;

#endif

