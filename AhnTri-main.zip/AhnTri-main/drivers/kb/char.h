#ifndef CHAR_H
#define CHAR_H

#include "../../libc/types/ctypes.h"
#include "keyboard.h"


extern char get_ascii_char(uint8);

#endif


