void memanset(){
  //Will be made again with real memory management
}

void memprintf(){
  //Will be made again with real memory management
}
