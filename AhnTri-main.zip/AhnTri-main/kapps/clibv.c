#include "../kernel.h"
#include "../libc/atclib.h"

void clibver(){
	printf("\n  \\____/      Ant C LIBRARY VERSION     ");
	printf("\n  |*_*|           1.2.5 ");
	printf("\n /|___|\\       GNU C Library                 ");
	printf("\n /|   |\\           10.2.0                ");
	printf("\n| |___| |                          ");
}
