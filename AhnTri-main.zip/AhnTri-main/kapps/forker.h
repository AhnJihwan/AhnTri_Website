void two(){
	two();
}

void prbomb(){
	printf("klasdjf#($*l;KLJDS(*FDS(DS DM*dfusm8dsumc()SDUFD8dusf0890-(jf#($*l;KLJDS(*FDS(DS DM*dfusm8dsumc()SDUFD*()e:");
	printf("adskl;fjcioooreu8f)*(F()*D()&(789&*(&dfj;dkscmaso)(*dsf)(*^&*%#@djf#($*l;KLJDS(*FDS(DS DM*dfusm8dsumc()SDUFDfdsaiuf$$%^dasf");
	printf("alsdjcf*)(*)(dsfj-==[;[];;,;?<>L::_d*(UDSUF*(80d98*0dfd\vsafajsdjf#($*l;KLJDS(*FDS(DS DM*dfusm8dsumc()SDUFDfjsdafs\vas]f");
	printf("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
}

void fbomb(){
	clscr();
	prbomb();
	prbomb();
	prbomb();
	prbomb();
	prbomb();
	prbomb();
	prbomb();
	prbomb();
	prbomb();
	prbomb();
	prbomb();
	prbomb();
	two();
}




