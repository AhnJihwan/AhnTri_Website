#include "../kernel.h"
#include "../libc/atclib.h"

void plant() {
	printf("Reconstructing...");
}
