void help(){
  printf("\nHELP for this help, CCALC for C calculator, OSVER for os version, clear/clscr for clear screen, exit for exiting, cputest for CPU testing, notes for NoteTaker, pedx for edx, atroid for ahntroid, homenu for GeX.\n\n");
  printf("\nMEMOR for memorize, MP for mem print");
}

