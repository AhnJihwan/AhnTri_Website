void help(){
  printf("\nHELP for this help, CCALC for C calculator, OSVER for os version, clear/clscr for clear screen, exit for exiting, cputest for CPU testing, notes for NoteTaker, pedx for edx, atroid for ahntroid\n\n");
  printf("\nMEMOR for memorize, MP for mem print, HALT for halt, GAME for game, SUN for sun ascii art, PLANT for plant ascii art, PIT for timer, CREDIT for credit, KMAP for kernel memory map, CLIBVER for c library version(Ant Clib/GCC)ADVSET for advanced settings");
}
