// For the command 'clscr'
void clscr(){
	framebuffer_clscr(0x000000);
}
/*
For LS@

*/
