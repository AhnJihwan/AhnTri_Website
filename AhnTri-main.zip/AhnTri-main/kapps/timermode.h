void timer(){
  pit();
}

