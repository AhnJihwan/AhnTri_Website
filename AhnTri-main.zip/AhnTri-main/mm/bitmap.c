/*
Bitmap Memory Manager.
COPYRIGHT 2021 JIHWAN AHN.
*/
